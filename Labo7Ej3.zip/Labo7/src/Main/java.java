package Main;

import java.util.Random;
import java.util.Scanner;

public class java {

    public static void main(String[] args) {
        int c = 0; // Cantidad de intentos
        boolean res;
        while (c < 5) {
            preguntar();
            c++;
        }
    }

    public static void preguntar() {
        Scanner sc = new Scanner(System.in);
        int n1, n2;
        int respuesta;

        n1 = getRandomNumberUsingNextInt(1, 10);
        n2 = getRandomNumberUsingNextInt(1, 10);

        System.out.println("¿Cuánto es " + n1 + " por " + n2 + "?");

        respuesta = Integer.parseInt(sc.nextLine());

        while (respuesta != n1 * n2) {
            System.out.println("“No. Por favor intenta de nuevo");
            System.out.println("¿Cuánto es " + n1 + " por " + n2 + "?");
            respuesta = Integer.parseInt(sc.nextLine());
        }
        
        System.out.println("¡Muy bien!");
    }

    public static int getRandomNumberUsingNextInt(int min, int max) {
        Random random = new Random();
        return random.nextInt(max - min) + min;
    }
}
