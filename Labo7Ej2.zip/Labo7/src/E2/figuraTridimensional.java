
package E2;

public abstract class figuraTridimensional extends figura {
    protected String tipoFiguraTri;
    protected String tipoCuerpoTri;

    public figuraTridimensional(String tipoFiguraTri, String tipoCuerpoTri) {
        this.tipoFiguraTri = tipoFiguraTri;
        this.tipoCuerpoTri = tipoCuerpoTri;
    }

    public String getTipoFiguraTri() {
        return tipoFiguraTri;
    }

    public void setTipoFiguraTri(String tipoFiguraTri) {
        this.tipoFiguraTri = tipoFiguraTri;
    }

    public String getTipoCuerpoTri() {
        return tipoCuerpoTri;
    }

    public void setTipoCuerpoTri(String tipoCuerpoTri) {
        this.tipoCuerpoTri = tipoCuerpoTri;
    }  
}
