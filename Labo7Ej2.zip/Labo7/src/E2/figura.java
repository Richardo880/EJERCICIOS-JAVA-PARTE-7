package E2;

public abstract class figura {
    public abstract double calcularArea();
    public abstract double calcularVolumen();
}
