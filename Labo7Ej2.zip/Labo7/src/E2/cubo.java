
package E2;

public class cubo extends figuraTridimensional {
    protected double lado;

    public cubo(String tipoFiguraTri, String tipoCuerpoTri, double lado) {
        super(tipoFiguraTri, tipoCuerpoTri);
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }  

    @Override
    public double calcularArea() {
        return 6 * Math.pow(this.lado,2);
    }

    @Override
    public double calcularVolumen() {
        return Math.pow(this.lado, 3);
    } 
}
