
package E2;

public class cuadrado extends figuraBidimensional {
    protected double lado;

    public cuadrado(String tipoFiguraBi, String tipoCuerpoBi, double lado) {
        super(tipoFiguraBi, tipoCuerpoBi);
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }
  
    @Override
    public double calcularArea(){
        return Math.pow(this.lado,2);
    }
    
    @Override
    public double calcularVolumen() {
        return 0.0;
    } 
}
