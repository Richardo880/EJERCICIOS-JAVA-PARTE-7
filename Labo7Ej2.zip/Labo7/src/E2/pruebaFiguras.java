package E2;

public class pruebaFiguras {

    public static void main(String[] args) {
        figura [] figuras = new figura[6];
        
        figuras[0] = new circulo("Circulo","Figura Bidimensional",10);
        figuras[1] = new cuadrado("Cuadrado","Figura Bidimensional",15);
        figuras[2] = new triangulo("Triangulo","Figura Bidimensional",20,17);
        figuras[3] = new esfera("Esfera","Figura Tridimensional",7);
        figuras[4] = new cubo("Cubo","Figura Tridimensional",13);
        figuras[5] = new tetraedro("Tetraedro","Figura Tridimensional",19);
        
        System.out.println("Figuras Geometricas:\n");
     
        for(figura i: figuras){
            if(i instanceof figuraBidimensional){
                System.out.printf("Tipo de Cuerpo: Figura Bidimensional\n");
                if(i instanceof circulo){
                    System.out.printf("Tipo de Figura: Circulo\nArea: %.2f cm^2\n",
                                      i.calcularArea());
                }
                if(i instanceof cuadrado){
                    System.out.printf("Tipo de Figura: Cuadrado\nArea: %.2f cm^2\n",
                                      i.calcularArea());
                }
                if(i instanceof triangulo){
                    System.out.printf("Tipo de Figura: Triangulo\nArea: %.2f cm^2\n",
                                      i.calcularArea());
                }
            }
            if(i instanceof figuraTridimensional){
                System.out.printf("Tipo de Cuerpo: Figura Tridimensional\n");
                if(i instanceof esfera){
                    System.out.printf("Tipo de Figura: Esfera\nArea: %.2f cm^2\nVolumen: %.2f cm^3\n",
                                      i.calcularArea(),
                                        i.calcularVolumen());
                }
                if(i instanceof cubo){
                    System.out.printf("Tipo de Figura: cubo\nArea: %.2f cm^2\nVolumen: %.2f cm^3\n",
                                      i.calcularArea(),
                                        i.calcularVolumen());
                }
                if(i instanceof tetraedro){
                    System.out.printf("Tipo de Figura: Tetraedro\nArea: %.2f cm^2\nVolumen: %.2f cm^3\n",
                                      i.calcularArea(),
                                        i.calcularVolumen());
                }
            }
            System.out.println();
        }
    }
    
}
