
package E2;

public class triangulo extends figuraBidimensional {
    protected double base;
    protected double altura;

    public triangulo(String tipoFiguraBi, String tipoCuerpoBi, double base, double altura) {
        super(tipoFiguraBi, tipoCuerpoBi);
        this.base = base;
        this.altura = altura;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public double calcularArea(){
        return (this.base*this.altura)/2;
    }
    
    @Override
    public double calcularVolumen() {
        return 0.0;
    }  
}
