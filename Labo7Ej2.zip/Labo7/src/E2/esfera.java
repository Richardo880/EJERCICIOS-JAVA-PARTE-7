
package E2;

public class esfera extends figuraTridimensional {
    protected double radio;

    public esfera(String tipoFiguraTri, String tipoCuerpoTri, double radio) {
        super(tipoFiguraTri, tipoCuerpoTri);
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return 4 *(Math.PI * Math.pow(this.radio, 2));
    }

    @Override
    public double calcularVolumen() {
        return (4/3)*(Math.PI * Math.pow(this.radio, 2));
    }       
}
