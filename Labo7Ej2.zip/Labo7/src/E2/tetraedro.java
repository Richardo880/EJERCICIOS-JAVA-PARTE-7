
package E2;

public class tetraedro extends figuraTridimensional {
    protected double lado;

    public tetraedro(String tipoFiguraTri, String tipoCuerpoTri, double lado) {
        super(tipoFiguraTri, tipoCuerpoTri);
        this.lado = lado;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    @Override
    public double calcularArea() {
        return Math.sqrt(3)*Math.pow(this.lado,2);
    }

    @Override
    public double calcularVolumen() {
        return (Math.pow(this.lado,3)*Math.sqrt(2))/12;
    } 
}
