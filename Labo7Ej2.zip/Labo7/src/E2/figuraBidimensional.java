
package E2;

public abstract class figuraBidimensional extends figura {
    protected String tipoFiguraBi;
    protected String tipoCuerpoBi;

    public figuraBidimensional(String tipoFiguraBi, String tipoCuerpoBi) {
        this.tipoFiguraBi = tipoFiguraBi;
        this.tipoCuerpoBi = tipoCuerpoBi;
    }

    public String getTipoFiguraBi() {
        return tipoFiguraBi;
    }

    public void setTipoFiguraBi(String tipoFiguraBi) {
        this.tipoFiguraBi = tipoFiguraBi;
    }

    public String getTipoCuerpoBi() {
        return tipoCuerpoBi;
    }

    public void setTipoCuerpoBi(String tipoCuerpoBi) {
        this.tipoCuerpoBi = tipoCuerpoBi;
    }   
}
