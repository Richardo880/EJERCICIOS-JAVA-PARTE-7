
package E2;

public class circulo extends figuraBidimensional {
    protected double radio;

    public circulo(String tipoFiguraBi,String tipoCuerpoTri,double radio) {
        super(tipoFiguraBi,tipoCuerpoTri);
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }
    
    @Override
    public double calcularArea(){
        return Math.PI*(Math.pow(this.radio,2));
    }
    
    @Override
    public double calcularVolumen() {
        return 0.0;
    }  
}
